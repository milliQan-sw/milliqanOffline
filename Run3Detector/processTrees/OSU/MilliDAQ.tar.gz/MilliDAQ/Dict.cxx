// Do NOT change. Changes will be lost next time file is generated

#define R__DICTIONARY_FILENAME Dict
#define R__NO_DEPRECATION

/*******************************************************************/
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#define G__DICTIONARY
#include "RConfig.h"
#include "TClass.h"
#include "TDictAttributeMap.h"
#include "TInterpreter.h"
#include "TROOT.h"
#include "TBuffer.h"
#include "TMemberInspector.h"
#include "TInterpreter.h"
#include "TVirtualMutex.h"
#include "TError.h"

#ifndef G__ROOT
#define G__ROOT
#endif

#include "RtypesImp.h"
#include "TIsAProxy.h"
#include "TFileMergeInfo.h"
#include <algorithm>
#include "TCollectionProxyInfo.h"
/*******************************************************************/

#include "TDataMember.h"

// Header files passed as explicit arguments
#include "interface/DemonstratorConfiguration.h"
#include "interface/DemonstratorConstants.h"
#include "interface/GlobalEvent.h"
#include "interface/V1743Event.h"
#include "interface/V1743Configuration.h"
#include "interface/AddTriggerNumber.h"
#include "interface/TriggerBoardReader.h"

// Header files passed via #pragma extra_include

// The generated code does not explicitly qualify STL entities
namespace std {} using namespace std;

namespace ROOT {
   static TClass *mdaqcLcLGroupConfiguration_Dictionary();
   static void mdaqcLcLGroupConfiguration_TClassManip(TClass*);
   static void *new_mdaqcLcLGroupConfiguration(void *p = 0);
   static void *newArray_mdaqcLcLGroupConfiguration(Long_t size, void *p);
   static void delete_mdaqcLcLGroupConfiguration(void *p);
   static void deleteArray_mdaqcLcLGroupConfiguration(void *p);
   static void destruct_mdaqcLcLGroupConfiguration(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::mdaq::GroupConfiguration*)
   {
      ::mdaq::GroupConfiguration *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::mdaq::GroupConfiguration));
      static ::ROOT::TGenericClassInfo 
         instance("mdaq::GroupConfiguration", "V1743Configuration.h", 29,
                  typeid(::mdaq::GroupConfiguration), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &mdaqcLcLGroupConfiguration_Dictionary, isa_proxy, 4,
                  sizeof(::mdaq::GroupConfiguration) );
      instance.SetNew(&new_mdaqcLcLGroupConfiguration);
      instance.SetNewArray(&newArray_mdaqcLcLGroupConfiguration);
      instance.SetDelete(&delete_mdaqcLcLGroupConfiguration);
      instance.SetDeleteArray(&deleteArray_mdaqcLcLGroupConfiguration);
      instance.SetDestructor(&destruct_mdaqcLcLGroupConfiguration);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::mdaq::GroupConfiguration*)
   {
      return GenerateInitInstanceLocal((::mdaq::GroupConfiguration*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::mdaq::GroupConfiguration*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *mdaqcLcLGroupConfiguration_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::mdaq::GroupConfiguration*)0x0)->GetClass();
      mdaqcLcLGroupConfiguration_TClassManip(theClass);
   return theClass;
   }

   static void mdaqcLcLGroupConfiguration_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *mdaqcLcLChannelConfiguration_Dictionary();
   static void mdaqcLcLChannelConfiguration_TClassManip(TClass*);
   static void *new_mdaqcLcLChannelConfiguration(void *p = 0);
   static void *newArray_mdaqcLcLChannelConfiguration(Long_t size, void *p);
   static void delete_mdaqcLcLChannelConfiguration(void *p);
   static void deleteArray_mdaqcLcLChannelConfiguration(void *p);
   static void destruct_mdaqcLcLChannelConfiguration(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::mdaq::ChannelConfiguration*)
   {
      ::mdaq::ChannelConfiguration *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::mdaq::ChannelConfiguration));
      static ::ROOT::TGenericClassInfo 
         instance("mdaq::ChannelConfiguration", "V1743Configuration.h", 35,
                  typeid(::mdaq::ChannelConfiguration), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &mdaqcLcLChannelConfiguration_Dictionary, isa_proxy, 4,
                  sizeof(::mdaq::ChannelConfiguration) );
      instance.SetNew(&new_mdaqcLcLChannelConfiguration);
      instance.SetNewArray(&newArray_mdaqcLcLChannelConfiguration);
      instance.SetDelete(&delete_mdaqcLcLChannelConfiguration);
      instance.SetDeleteArray(&deleteArray_mdaqcLcLChannelConfiguration);
      instance.SetDestructor(&destruct_mdaqcLcLChannelConfiguration);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::mdaq::ChannelConfiguration*)
   {
      return GenerateInitInstanceLocal((::mdaq::ChannelConfiguration*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::mdaq::ChannelConfiguration*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *mdaqcLcLChannelConfiguration_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::mdaq::ChannelConfiguration*)0x0)->GetClass();
      mdaqcLcLChannelConfiguration_TClassManip(theClass);
   return theClass;
   }

   static void mdaqcLcLChannelConfiguration_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static void *new_mdaqcLcLV1743Configuration(void *p = 0);
   static void *newArray_mdaqcLcLV1743Configuration(Long_t size, void *p);
   static void delete_mdaqcLcLV1743Configuration(void *p);
   static void deleteArray_mdaqcLcLV1743Configuration(void *p);
   static void destruct_mdaqcLcLV1743Configuration(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::mdaq::V1743Configuration*)
   {
      ::mdaq::V1743Configuration *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TInstrumentedIsAProxy< ::mdaq::V1743Configuration >(0);
      static ::ROOT::TGenericClassInfo 
         instance("mdaq::V1743Configuration", ::mdaq::V1743Configuration::Class_Version(), "V1743Configuration.h", 54,
                  typeid(::mdaq::V1743Configuration), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &::mdaq::V1743Configuration::Dictionary, isa_proxy, 4,
                  sizeof(::mdaq::V1743Configuration) );
      instance.SetNew(&new_mdaqcLcLV1743Configuration);
      instance.SetNewArray(&newArray_mdaqcLcLV1743Configuration);
      instance.SetDelete(&delete_mdaqcLcLV1743Configuration);
      instance.SetDeleteArray(&deleteArray_mdaqcLcLV1743Configuration);
      instance.SetDestructor(&destruct_mdaqcLcLV1743Configuration);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::mdaq::V1743Configuration*)
   {
      return GenerateInitInstanceLocal((::mdaq::V1743Configuration*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::mdaq::V1743Configuration*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));
} // end of namespace ROOT

namespace ROOT {
   static TClass *HVConfiguration_Dictionary();
   static void HVConfiguration_TClassManip(TClass*);
   static void *new_HVConfiguration(void *p = 0);
   static void *newArray_HVConfiguration(Long_t size, void *p);
   static void delete_HVConfiguration(void *p);
   static void deleteArray_HVConfiguration(void *p);
   static void destruct_HVConfiguration(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::HVConfiguration*)
   {
      ::HVConfiguration *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::HVConfiguration));
      static ::ROOT::TGenericClassInfo 
         instance("HVConfiguration", "DemonstratorConfiguration.h", 18,
                  typeid(::HVConfiguration), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &HVConfiguration_Dictionary, isa_proxy, 4,
                  sizeof(::HVConfiguration) );
      instance.SetNew(&new_HVConfiguration);
      instance.SetNewArray(&newArray_HVConfiguration);
      instance.SetDelete(&delete_HVConfiguration);
      instance.SetDeleteArray(&deleteArray_HVConfiguration);
      instance.SetDestructor(&destruct_HVConfiguration);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::HVConfiguration*)
   {
      return GenerateInitInstanceLocal((::HVConfiguration*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::HVConfiguration*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *HVConfiguration_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::HVConfiguration*)0x0)->GetClass();
      HVConfiguration_TClassManip(theClass);
   return theClass;
   }

   static void HVConfiguration_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static void *new_mdaqcLcLDemonstratorConfiguration(void *p = 0);
   static void *newArray_mdaqcLcLDemonstratorConfiguration(Long_t size, void *p);
   static void delete_mdaqcLcLDemonstratorConfiguration(void *p);
   static void deleteArray_mdaqcLcLDemonstratorConfiguration(void *p);
   static void destruct_mdaqcLcLDemonstratorConfiguration(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::mdaq::DemonstratorConfiguration*)
   {
      ::mdaq::DemonstratorConfiguration *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TInstrumentedIsAProxy< ::mdaq::DemonstratorConfiguration >(0);
      static ::ROOT::TGenericClassInfo 
         instance("mdaq::DemonstratorConfiguration", ::mdaq::DemonstratorConfiguration::Class_Version(), "DemonstratorConfiguration.h", 26,
                  typeid(::mdaq::DemonstratorConfiguration), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &::mdaq::DemonstratorConfiguration::Dictionary, isa_proxy, 4,
                  sizeof(::mdaq::DemonstratorConfiguration) );
      instance.SetNew(&new_mdaqcLcLDemonstratorConfiguration);
      instance.SetNewArray(&newArray_mdaqcLcLDemonstratorConfiguration);
      instance.SetDelete(&delete_mdaqcLcLDemonstratorConfiguration);
      instance.SetDeleteArray(&deleteArray_mdaqcLcLDemonstratorConfiguration);
      instance.SetDestructor(&destruct_mdaqcLcLDemonstratorConfiguration);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::mdaq::DemonstratorConfiguration*)
   {
      return GenerateInitInstanceLocal((::mdaq::DemonstratorConfiguration*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::mdaq::DemonstratorConfiguration*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));
} // end of namespace ROOT

namespace ROOT {
   static void *new_mdaqcLcLV1743Event(void *p = 0);
   static void *newArray_mdaqcLcLV1743Event(Long_t size, void *p);
   static void delete_mdaqcLcLV1743Event(void *p);
   static void deleteArray_mdaqcLcLV1743Event(void *p);
   static void destruct_mdaqcLcLV1743Event(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::mdaq::V1743Event*)
   {
      ::mdaq::V1743Event *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TInstrumentedIsAProxy< ::mdaq::V1743Event >(0);
      static ::ROOT::TGenericClassInfo 
         instance("mdaq::V1743Event", ::mdaq::V1743Event::Class_Version(), "V1743Event.h", 25,
                  typeid(::mdaq::V1743Event), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &::mdaq::V1743Event::Dictionary, isa_proxy, 4,
                  sizeof(::mdaq::V1743Event) );
      instance.SetNew(&new_mdaqcLcLV1743Event);
      instance.SetNewArray(&newArray_mdaqcLcLV1743Event);
      instance.SetDelete(&delete_mdaqcLcLV1743Event);
      instance.SetDeleteArray(&deleteArray_mdaqcLcLV1743Event);
      instance.SetDestructor(&destruct_mdaqcLcLV1743Event);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::mdaq::V1743Event*)
   {
      return GenerateInitInstanceLocal((::mdaq::V1743Event*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::mdaq::V1743Event*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));
} // end of namespace ROOT

namespace ROOT {
   static void *new_mdaqcLcLGlobalEvent(void *p = 0);
   static void *newArray_mdaqcLcLGlobalEvent(Long_t size, void *p);
   static void delete_mdaqcLcLGlobalEvent(void *p);
   static void deleteArray_mdaqcLcLGlobalEvent(void *p);
   static void destruct_mdaqcLcLGlobalEvent(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::mdaq::GlobalEvent*)
   {
      ::mdaq::GlobalEvent *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TInstrumentedIsAProxy< ::mdaq::GlobalEvent >(0);
      static ::ROOT::TGenericClassInfo 
         instance("mdaq::GlobalEvent", ::mdaq::GlobalEvent::Class_Version(), "GlobalEvent.h", 19,
                  typeid(::mdaq::GlobalEvent), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &::mdaq::GlobalEvent::Dictionary, isa_proxy, 4,
                  sizeof(::mdaq::GlobalEvent) );
      instance.SetNew(&new_mdaqcLcLGlobalEvent);
      instance.SetNewArray(&newArray_mdaqcLcLGlobalEvent);
      instance.SetDelete(&delete_mdaqcLcLGlobalEvent);
      instance.SetDeleteArray(&deleteArray_mdaqcLcLGlobalEvent);
      instance.SetDestructor(&destruct_mdaqcLcLGlobalEvent);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::mdaq::GlobalEvent*)
   {
      return GenerateInitInstanceLocal((::mdaq::GlobalEvent*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::mdaq::GlobalEvent*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));
} // end of namespace ROOT

namespace ROOT {
   static TClass *mdaqcLcLeventTimes_Dictionary();
   static void mdaqcLcLeventTimes_TClassManip(TClass*);
   static void *new_mdaqcLcLeventTimes(void *p = 0);
   static void *newArray_mdaqcLcLeventTimes(Long_t size, void *p);
   static void delete_mdaqcLcLeventTimes(void *p);
   static void deleteArray_mdaqcLcLeventTimes(void *p);
   static void destruct_mdaqcLcLeventTimes(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::mdaq::eventTimes*)
   {
      ::mdaq::eventTimes *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::mdaq::eventTimes));
      static ::ROOT::TGenericClassInfo 
         instance("mdaq::eventTimes", "AddTriggerNumber.h", 20,
                  typeid(::mdaq::eventTimes), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &mdaqcLcLeventTimes_Dictionary, isa_proxy, 4,
                  sizeof(::mdaq::eventTimes) );
      instance.SetNew(&new_mdaqcLcLeventTimes);
      instance.SetNewArray(&newArray_mdaqcLcLeventTimes);
      instance.SetDelete(&delete_mdaqcLcLeventTimes);
      instance.SetDeleteArray(&deleteArray_mdaqcLcLeventTimes);
      instance.SetDestructor(&destruct_mdaqcLcLeventTimes);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::mdaq::eventTimes*)
   {
      return GenerateInitInstanceLocal((::mdaq::eventTimes*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::mdaq::eventTimes*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *mdaqcLcLeventTimes_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::mdaq::eventTimes*)0x0)->GetClass();
      mdaqcLcLeventTimes_TClassManip(theClass);
   return theClass;
   }

   static void mdaqcLcLeventTimes_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace mdaq {
//______________________________________________________________________________
atomic_TClass_ptr V1743Configuration::fgIsA(0);  // static to hold class pointer

//______________________________________________________________________________
const char *V1743Configuration::Class_Name()
{
   return "mdaq::V1743Configuration";
}

//______________________________________________________________________________
const char *V1743Configuration::ImplFileName()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::mdaq::V1743Configuration*)0x0)->GetImplFileName();
}

//______________________________________________________________________________
int V1743Configuration::ImplFileLine()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::mdaq::V1743Configuration*)0x0)->GetImplFileLine();
}

//______________________________________________________________________________
TClass *V1743Configuration::Dictionary()
{
   fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::mdaq::V1743Configuration*)0x0)->GetClass();
   return fgIsA;
}

//______________________________________________________________________________
TClass *V1743Configuration::Class()
{
   if (!fgIsA.load()) { R__LOCKGUARD(gInterpreterMutex); fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::mdaq::V1743Configuration*)0x0)->GetClass(); }
   return fgIsA;
}

} // namespace mdaq
namespace mdaq {
//______________________________________________________________________________
atomic_TClass_ptr DemonstratorConfiguration::fgIsA(0);  // static to hold class pointer

//______________________________________________________________________________
const char *DemonstratorConfiguration::Class_Name()
{
   return "mdaq::DemonstratorConfiguration";
}

//______________________________________________________________________________
const char *DemonstratorConfiguration::ImplFileName()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::mdaq::DemonstratorConfiguration*)0x0)->GetImplFileName();
}

//______________________________________________________________________________
int DemonstratorConfiguration::ImplFileLine()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::mdaq::DemonstratorConfiguration*)0x0)->GetImplFileLine();
}

//______________________________________________________________________________
TClass *DemonstratorConfiguration::Dictionary()
{
   fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::mdaq::DemonstratorConfiguration*)0x0)->GetClass();
   return fgIsA;
}

//______________________________________________________________________________
TClass *DemonstratorConfiguration::Class()
{
   if (!fgIsA.load()) { R__LOCKGUARD(gInterpreterMutex); fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::mdaq::DemonstratorConfiguration*)0x0)->GetClass(); }
   return fgIsA;
}

} // namespace mdaq
namespace mdaq {
//______________________________________________________________________________
atomic_TClass_ptr V1743Event::fgIsA(0);  // static to hold class pointer

//______________________________________________________________________________
const char *V1743Event::Class_Name()
{
   return "mdaq::V1743Event";
}

//______________________________________________________________________________
const char *V1743Event::ImplFileName()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::mdaq::V1743Event*)0x0)->GetImplFileName();
}

//______________________________________________________________________________
int V1743Event::ImplFileLine()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::mdaq::V1743Event*)0x0)->GetImplFileLine();
}

//______________________________________________________________________________
TClass *V1743Event::Dictionary()
{
   fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::mdaq::V1743Event*)0x0)->GetClass();
   return fgIsA;
}

//______________________________________________________________________________
TClass *V1743Event::Class()
{
   if (!fgIsA.load()) { R__LOCKGUARD(gInterpreterMutex); fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::mdaq::V1743Event*)0x0)->GetClass(); }
   return fgIsA;
}

} // namespace mdaq
namespace mdaq {
//______________________________________________________________________________
atomic_TClass_ptr GlobalEvent::fgIsA(0);  // static to hold class pointer

//______________________________________________________________________________
const char *GlobalEvent::Class_Name()
{
   return "mdaq::GlobalEvent";
}

//______________________________________________________________________________
const char *GlobalEvent::ImplFileName()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::mdaq::GlobalEvent*)0x0)->GetImplFileName();
}

//______________________________________________________________________________
int GlobalEvent::ImplFileLine()
{
   return ::ROOT::GenerateInitInstanceLocal((const ::mdaq::GlobalEvent*)0x0)->GetImplFileLine();
}

//______________________________________________________________________________
TClass *GlobalEvent::Dictionary()
{
   fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::mdaq::GlobalEvent*)0x0)->GetClass();
   return fgIsA;
}

//______________________________________________________________________________
TClass *GlobalEvent::Class()
{
   if (!fgIsA.load()) { R__LOCKGUARD(gInterpreterMutex); fgIsA = ::ROOT::GenerateInitInstanceLocal((const ::mdaq::GlobalEvent*)0x0)->GetClass(); }
   return fgIsA;
}

} // namespace mdaq
namespace ROOT {
   // Wrappers around operator new
   static void *new_mdaqcLcLGroupConfiguration(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::mdaq::GroupConfiguration : new ::mdaq::GroupConfiguration;
   }
   static void *newArray_mdaqcLcLGroupConfiguration(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::mdaq::GroupConfiguration[nElements] : new ::mdaq::GroupConfiguration[nElements];
   }
   // Wrapper around operator delete
   static void delete_mdaqcLcLGroupConfiguration(void *p) {
      delete ((::mdaq::GroupConfiguration*)p);
   }
   static void deleteArray_mdaqcLcLGroupConfiguration(void *p) {
      delete [] ((::mdaq::GroupConfiguration*)p);
   }
   static void destruct_mdaqcLcLGroupConfiguration(void *p) {
      typedef ::mdaq::GroupConfiguration current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::mdaq::GroupConfiguration

namespace ROOT {
   // Wrappers around operator new
   static void *new_mdaqcLcLChannelConfiguration(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::mdaq::ChannelConfiguration : new ::mdaq::ChannelConfiguration;
   }
   static void *newArray_mdaqcLcLChannelConfiguration(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::mdaq::ChannelConfiguration[nElements] : new ::mdaq::ChannelConfiguration[nElements];
   }
   // Wrapper around operator delete
   static void delete_mdaqcLcLChannelConfiguration(void *p) {
      delete ((::mdaq::ChannelConfiguration*)p);
   }
   static void deleteArray_mdaqcLcLChannelConfiguration(void *p) {
      delete [] ((::mdaq::ChannelConfiguration*)p);
   }
   static void destruct_mdaqcLcLChannelConfiguration(void *p) {
      typedef ::mdaq::ChannelConfiguration current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::mdaq::ChannelConfiguration

namespace mdaq {
//______________________________________________________________________________
void V1743Configuration::Streamer(TBuffer &R__b)
{
   // Stream an object of class mdaq::V1743Configuration.

   if (R__b.IsReading()) {
      R__b.ReadClassBuffer(mdaq::V1743Configuration::Class(),this);
   } else {
      R__b.WriteClassBuffer(mdaq::V1743Configuration::Class(),this);
   }
}

} // namespace mdaq
namespace ROOT {
   // Wrappers around operator new
   static void *new_mdaqcLcLV1743Configuration(void *p) {
      return  p ? new(p) ::mdaq::V1743Configuration : new ::mdaq::V1743Configuration;
   }
   static void *newArray_mdaqcLcLV1743Configuration(Long_t nElements, void *p) {
      return p ? new(p) ::mdaq::V1743Configuration[nElements] : new ::mdaq::V1743Configuration[nElements];
   }
   // Wrapper around operator delete
   static void delete_mdaqcLcLV1743Configuration(void *p) {
      delete ((::mdaq::V1743Configuration*)p);
   }
   static void deleteArray_mdaqcLcLV1743Configuration(void *p) {
      delete [] ((::mdaq::V1743Configuration*)p);
   }
   static void destruct_mdaqcLcLV1743Configuration(void *p) {
      typedef ::mdaq::V1743Configuration current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::mdaq::V1743Configuration

namespace ROOT {
   // Wrappers around operator new
   static void *new_HVConfiguration(void *p) {
      return  p ? new(p) ::HVConfiguration : new ::HVConfiguration;
   }
   static void *newArray_HVConfiguration(Long_t nElements, void *p) {
      return p ? new(p) ::HVConfiguration[nElements] : new ::HVConfiguration[nElements];
   }
   // Wrapper around operator delete
   static void delete_HVConfiguration(void *p) {
      delete ((::HVConfiguration*)p);
   }
   static void deleteArray_HVConfiguration(void *p) {
      delete [] ((::HVConfiguration*)p);
   }
   static void destruct_HVConfiguration(void *p) {
      typedef ::HVConfiguration current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::HVConfiguration

namespace mdaq {
//______________________________________________________________________________
void DemonstratorConfiguration::Streamer(TBuffer &R__b)
{
   // Stream an object of class mdaq::DemonstratorConfiguration.

   if (R__b.IsReading()) {
      R__b.ReadClassBuffer(mdaq::DemonstratorConfiguration::Class(),this);
   } else {
      R__b.WriteClassBuffer(mdaq::DemonstratorConfiguration::Class(),this);
   }
}

} // namespace mdaq
namespace ROOT {
   // Wrappers around operator new
   static void *new_mdaqcLcLDemonstratorConfiguration(void *p) {
      return  p ? new(p) ::mdaq::DemonstratorConfiguration : new ::mdaq::DemonstratorConfiguration;
   }
   static void *newArray_mdaqcLcLDemonstratorConfiguration(Long_t nElements, void *p) {
      return p ? new(p) ::mdaq::DemonstratorConfiguration[nElements] : new ::mdaq::DemonstratorConfiguration[nElements];
   }
   // Wrapper around operator delete
   static void delete_mdaqcLcLDemonstratorConfiguration(void *p) {
      delete ((::mdaq::DemonstratorConfiguration*)p);
   }
   static void deleteArray_mdaqcLcLDemonstratorConfiguration(void *p) {
      delete [] ((::mdaq::DemonstratorConfiguration*)p);
   }
   static void destruct_mdaqcLcLDemonstratorConfiguration(void *p) {
      typedef ::mdaq::DemonstratorConfiguration current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::mdaq::DemonstratorConfiguration

namespace mdaq {
//______________________________________________________________________________
void V1743Event::Streamer(TBuffer &R__b)
{
   // Stream an object of class mdaq::V1743Event.

   if (R__b.IsReading()) {
      R__b.ReadClassBuffer(mdaq::V1743Event::Class(),this);
   } else {
      R__b.WriteClassBuffer(mdaq::V1743Event::Class(),this);
   }
}

} // namespace mdaq
namespace ROOT {
   // Wrappers around operator new
   static void *new_mdaqcLcLV1743Event(void *p) {
      return  p ? new(p) ::mdaq::V1743Event : new ::mdaq::V1743Event;
   }
   static void *newArray_mdaqcLcLV1743Event(Long_t nElements, void *p) {
      return p ? new(p) ::mdaq::V1743Event[nElements] : new ::mdaq::V1743Event[nElements];
   }
   // Wrapper around operator delete
   static void delete_mdaqcLcLV1743Event(void *p) {
      delete ((::mdaq::V1743Event*)p);
   }
   static void deleteArray_mdaqcLcLV1743Event(void *p) {
      delete [] ((::mdaq::V1743Event*)p);
   }
   static void destruct_mdaqcLcLV1743Event(void *p) {
      typedef ::mdaq::V1743Event current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::mdaq::V1743Event

namespace mdaq {
//______________________________________________________________________________
void GlobalEvent::Streamer(TBuffer &R__b)
{
   // Stream an object of class mdaq::GlobalEvent.

   if (R__b.IsReading()) {
      R__b.ReadClassBuffer(mdaq::GlobalEvent::Class(),this);
   } else {
      R__b.WriteClassBuffer(mdaq::GlobalEvent::Class(),this);
   }
}

} // namespace mdaq
namespace ROOT {
   // Wrappers around operator new
   static void *new_mdaqcLcLGlobalEvent(void *p) {
      return  p ? new(p) ::mdaq::GlobalEvent : new ::mdaq::GlobalEvent;
   }
   static void *newArray_mdaqcLcLGlobalEvent(Long_t nElements, void *p) {
      return p ? new(p) ::mdaq::GlobalEvent[nElements] : new ::mdaq::GlobalEvent[nElements];
   }
   // Wrapper around operator delete
   static void delete_mdaqcLcLGlobalEvent(void *p) {
      delete ((::mdaq::GlobalEvent*)p);
   }
   static void deleteArray_mdaqcLcLGlobalEvent(void *p) {
      delete [] ((::mdaq::GlobalEvent*)p);
   }
   static void destruct_mdaqcLcLGlobalEvent(void *p) {
      typedef ::mdaq::GlobalEvent current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::mdaq::GlobalEvent

namespace ROOT {
   // Wrappers around operator new
   static void *new_mdaqcLcLeventTimes(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::mdaq::eventTimes : new ::mdaq::eventTimes;
   }
   static void *newArray_mdaqcLcLeventTimes(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::mdaq::eventTimes[nElements] : new ::mdaq::eventTimes[nElements];
   }
   // Wrapper around operator delete
   static void delete_mdaqcLcLeventTimes(void *p) {
      delete ((::mdaq::eventTimes*)p);
   }
   static void deleteArray_mdaqcLcLeventTimes(void *p) {
      delete [] ((::mdaq::eventTimes*)p);
   }
   static void destruct_mdaqcLcLeventTimes(void *p) {
      typedef ::mdaq::eventTimes current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::mdaq::eventTimes

namespace ROOT {
   static TClass *vectorlEmdaqcLcLV1743EventgR_Dictionary();
   static void vectorlEmdaqcLcLV1743EventgR_TClassManip(TClass*);
   static void *new_vectorlEmdaqcLcLV1743EventgR(void *p = 0);
   static void *newArray_vectorlEmdaqcLcLV1743EventgR(Long_t size, void *p);
   static void delete_vectorlEmdaqcLcLV1743EventgR(void *p);
   static void deleteArray_vectorlEmdaqcLcLV1743EventgR(void *p);
   static void destruct_vectorlEmdaqcLcLV1743EventgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<mdaq::V1743Event>*)
   {
      vector<mdaq::V1743Event> *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<mdaq::V1743Event>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<mdaq::V1743Event>", -2, "vector", 210,
                  typeid(vector<mdaq::V1743Event>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEmdaqcLcLV1743EventgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<mdaq::V1743Event>) );
      instance.SetNew(&new_vectorlEmdaqcLcLV1743EventgR);
      instance.SetNewArray(&newArray_vectorlEmdaqcLcLV1743EventgR);
      instance.SetDelete(&delete_vectorlEmdaqcLcLV1743EventgR);
      instance.SetDeleteArray(&deleteArray_vectorlEmdaqcLcLV1743EventgR);
      instance.SetDestructor(&destruct_vectorlEmdaqcLcLV1743EventgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<mdaq::V1743Event> >()));

      ::ROOT::AddClassAlternate("vector<mdaq::V1743Event>","std::vector<mdaq::V1743Event, std::allocator<mdaq::V1743Event> >");
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<mdaq::V1743Event>*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEmdaqcLcLV1743EventgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<mdaq::V1743Event>*)0x0)->GetClass();
      vectorlEmdaqcLcLV1743EventgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEmdaqcLcLV1743EventgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEmdaqcLcLV1743EventgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<mdaq::V1743Event> : new vector<mdaq::V1743Event>;
   }
   static void *newArray_vectorlEmdaqcLcLV1743EventgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<mdaq::V1743Event>[nElements] : new vector<mdaq::V1743Event>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEmdaqcLcLV1743EventgR(void *p) {
      delete ((vector<mdaq::V1743Event>*)p);
   }
   static void deleteArray_vectorlEmdaqcLcLV1743EventgR(void *p) {
      delete [] ((vector<mdaq::V1743Event>*)p);
   }
   static void destruct_vectorlEmdaqcLcLV1743EventgR(void *p) {
      typedef vector<mdaq::V1743Event> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<mdaq::V1743Event>

namespace ROOT {
   static TClass *vectorlEmdaqcLcLV1743ConfigurationgR_Dictionary();
   static void vectorlEmdaqcLcLV1743ConfigurationgR_TClassManip(TClass*);
   static void *new_vectorlEmdaqcLcLV1743ConfigurationgR(void *p = 0);
   static void *newArray_vectorlEmdaqcLcLV1743ConfigurationgR(Long_t size, void *p);
   static void delete_vectorlEmdaqcLcLV1743ConfigurationgR(void *p);
   static void deleteArray_vectorlEmdaqcLcLV1743ConfigurationgR(void *p);
   static void destruct_vectorlEmdaqcLcLV1743ConfigurationgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<mdaq::V1743Configuration>*)
   {
      vector<mdaq::V1743Configuration> *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<mdaq::V1743Configuration>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<mdaq::V1743Configuration>", -2, "vector", 210,
                  typeid(vector<mdaq::V1743Configuration>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEmdaqcLcLV1743ConfigurationgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<mdaq::V1743Configuration>) );
      instance.SetNew(&new_vectorlEmdaqcLcLV1743ConfigurationgR);
      instance.SetNewArray(&newArray_vectorlEmdaqcLcLV1743ConfigurationgR);
      instance.SetDelete(&delete_vectorlEmdaqcLcLV1743ConfigurationgR);
      instance.SetDeleteArray(&deleteArray_vectorlEmdaqcLcLV1743ConfigurationgR);
      instance.SetDestructor(&destruct_vectorlEmdaqcLcLV1743ConfigurationgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<mdaq::V1743Configuration> >()));

      ::ROOT::AddClassAlternate("vector<mdaq::V1743Configuration>","std::vector<mdaq::V1743Configuration, std::allocator<mdaq::V1743Configuration> >");
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<mdaq::V1743Configuration>*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEmdaqcLcLV1743ConfigurationgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<mdaq::V1743Configuration>*)0x0)->GetClass();
      vectorlEmdaqcLcLV1743ConfigurationgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEmdaqcLcLV1743ConfigurationgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEmdaqcLcLV1743ConfigurationgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<mdaq::V1743Configuration> : new vector<mdaq::V1743Configuration>;
   }
   static void *newArray_vectorlEmdaqcLcLV1743ConfigurationgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<mdaq::V1743Configuration>[nElements] : new vector<mdaq::V1743Configuration>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEmdaqcLcLV1743ConfigurationgR(void *p) {
      delete ((vector<mdaq::V1743Configuration>*)p);
   }
   static void deleteArray_vectorlEmdaqcLcLV1743ConfigurationgR(void *p) {
      delete [] ((vector<mdaq::V1743Configuration>*)p);
   }
   static void destruct_vectorlEmdaqcLcLV1743ConfigurationgR(void *p) {
      typedef vector<mdaq::V1743Configuration> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<mdaq::V1743Configuration>

namespace ROOT {
   static TClass *vectorlEmdaqcLcLGroupConfigurationgR_Dictionary();
   static void vectorlEmdaqcLcLGroupConfigurationgR_TClassManip(TClass*);
   static void *new_vectorlEmdaqcLcLGroupConfigurationgR(void *p = 0);
   static void *newArray_vectorlEmdaqcLcLGroupConfigurationgR(Long_t size, void *p);
   static void delete_vectorlEmdaqcLcLGroupConfigurationgR(void *p);
   static void deleteArray_vectorlEmdaqcLcLGroupConfigurationgR(void *p);
   static void destruct_vectorlEmdaqcLcLGroupConfigurationgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<mdaq::GroupConfiguration>*)
   {
      vector<mdaq::GroupConfiguration> *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<mdaq::GroupConfiguration>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<mdaq::GroupConfiguration>", -2, "vector", 210,
                  typeid(vector<mdaq::GroupConfiguration>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEmdaqcLcLGroupConfigurationgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<mdaq::GroupConfiguration>) );
      instance.SetNew(&new_vectorlEmdaqcLcLGroupConfigurationgR);
      instance.SetNewArray(&newArray_vectorlEmdaqcLcLGroupConfigurationgR);
      instance.SetDelete(&delete_vectorlEmdaqcLcLGroupConfigurationgR);
      instance.SetDeleteArray(&deleteArray_vectorlEmdaqcLcLGroupConfigurationgR);
      instance.SetDestructor(&destruct_vectorlEmdaqcLcLGroupConfigurationgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<mdaq::GroupConfiguration> >()));

      ::ROOT::AddClassAlternate("vector<mdaq::GroupConfiguration>","std::vector<mdaq::GroupConfiguration, std::allocator<mdaq::GroupConfiguration> >");
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<mdaq::GroupConfiguration>*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEmdaqcLcLGroupConfigurationgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<mdaq::GroupConfiguration>*)0x0)->GetClass();
      vectorlEmdaqcLcLGroupConfigurationgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEmdaqcLcLGroupConfigurationgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEmdaqcLcLGroupConfigurationgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<mdaq::GroupConfiguration> : new vector<mdaq::GroupConfiguration>;
   }
   static void *newArray_vectorlEmdaqcLcLGroupConfigurationgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<mdaq::GroupConfiguration>[nElements] : new vector<mdaq::GroupConfiguration>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEmdaqcLcLGroupConfigurationgR(void *p) {
      delete ((vector<mdaq::GroupConfiguration>*)p);
   }
   static void deleteArray_vectorlEmdaqcLcLGroupConfigurationgR(void *p) {
      delete [] ((vector<mdaq::GroupConfiguration>*)p);
   }
   static void destruct_vectorlEmdaqcLcLGroupConfigurationgR(void *p) {
      typedef vector<mdaq::GroupConfiguration> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<mdaq::GroupConfiguration>

namespace ROOT {
   static TClass *vectorlEmdaqcLcLChannelConfigurationgR_Dictionary();
   static void vectorlEmdaqcLcLChannelConfigurationgR_TClassManip(TClass*);
   static void *new_vectorlEmdaqcLcLChannelConfigurationgR(void *p = 0);
   static void *newArray_vectorlEmdaqcLcLChannelConfigurationgR(Long_t size, void *p);
   static void delete_vectorlEmdaqcLcLChannelConfigurationgR(void *p);
   static void deleteArray_vectorlEmdaqcLcLChannelConfigurationgR(void *p);
   static void destruct_vectorlEmdaqcLcLChannelConfigurationgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<mdaq::ChannelConfiguration>*)
   {
      vector<mdaq::ChannelConfiguration> *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<mdaq::ChannelConfiguration>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<mdaq::ChannelConfiguration>", -2, "vector", 210,
                  typeid(vector<mdaq::ChannelConfiguration>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEmdaqcLcLChannelConfigurationgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<mdaq::ChannelConfiguration>) );
      instance.SetNew(&new_vectorlEmdaqcLcLChannelConfigurationgR);
      instance.SetNewArray(&newArray_vectorlEmdaqcLcLChannelConfigurationgR);
      instance.SetDelete(&delete_vectorlEmdaqcLcLChannelConfigurationgR);
      instance.SetDeleteArray(&deleteArray_vectorlEmdaqcLcLChannelConfigurationgR);
      instance.SetDestructor(&destruct_vectorlEmdaqcLcLChannelConfigurationgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<mdaq::ChannelConfiguration> >()));

      ::ROOT::AddClassAlternate("vector<mdaq::ChannelConfiguration>","std::vector<mdaq::ChannelConfiguration, std::allocator<mdaq::ChannelConfiguration> >");
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<mdaq::ChannelConfiguration>*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEmdaqcLcLChannelConfigurationgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<mdaq::ChannelConfiguration>*)0x0)->GetClass();
      vectorlEmdaqcLcLChannelConfigurationgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEmdaqcLcLChannelConfigurationgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEmdaqcLcLChannelConfigurationgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<mdaq::ChannelConfiguration> : new vector<mdaq::ChannelConfiguration>;
   }
   static void *newArray_vectorlEmdaqcLcLChannelConfigurationgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<mdaq::ChannelConfiguration>[nElements] : new vector<mdaq::ChannelConfiguration>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEmdaqcLcLChannelConfigurationgR(void *p) {
      delete ((vector<mdaq::ChannelConfiguration>*)p);
   }
   static void deleteArray_vectorlEmdaqcLcLChannelConfigurationgR(void *p) {
      delete [] ((vector<mdaq::ChannelConfiguration>*)p);
   }
   static void destruct_vectorlEmdaqcLcLChannelConfigurationgR(void *p) {
      typedef vector<mdaq::ChannelConfiguration> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<mdaq::ChannelConfiguration>

namespace {
  void TriggerDictionaryInitialization_Dict_Impl() {
    static const char* headers[] = {
"interface/DemonstratorConfiguration.h",
"interface/DemonstratorConstants.h",
"interface/GlobalEvent.h",
"interface/V1743Event.h",
"interface/V1743Configuration.h",
"interface/AddTriggerNumber.h",
"interface/TriggerBoardReader.h",
0
    };
    static const char* includePaths[] = {
"./interface",
"/usr/include/root",
"/usr/include/root",
"/share/scratch0/milliqan/processTrees/MilliDAQ/",
0
    };
    static const char* fwdDeclCode = R"DICTFWDDCLS(
#line 1 "Dict dictionary forward declarations' payload"
#pragma clang diagnostic ignored "-Wkeyword-compat"
#pragma clang diagnostic ignored "-Wignored-attributes"
#pragma clang diagnostic ignored "-Wreturn-type-c-linkage"
extern int __Cling_AutoLoading_Map;
namespace mdaq{struct __attribute__((annotate("$clingAutoload$V1743Configuration.h")))  __attribute__((annotate("$clingAutoload$interface/DemonstratorConfiguration.h")))  GroupConfiguration;}
namespace std{template <typename _Tp> class __attribute__((annotate("$clingAutoload$bits/allocator.h")))  __attribute__((annotate("$clingAutoload$string")))  allocator;
}
namespace mdaq{struct __attribute__((annotate("$clingAutoload$V1743Configuration.h")))  __attribute__((annotate("$clingAutoload$interface/DemonstratorConfiguration.h")))  ChannelConfiguration;}
namespace mdaq{class __attribute__((annotate("$clingAutoload$V1743Configuration.h")))  __attribute__((annotate("$clingAutoload$interface/DemonstratorConfiguration.h")))  V1743Configuration;}
namespace mdaq{class __attribute__((annotate("$clingAutoload$V1743Event.h")))  __attribute__((annotate("$clingAutoload$interface/GlobalEvent.h")))  V1743Event;}
struct __attribute__((annotate("$clingAutoload$interface/DemonstratorConfiguration.h")))  HVConfiguration;
namespace mdaq{class __attribute__((annotate("$clingAutoload$interface/DemonstratorConfiguration.h")))  DemonstratorConfiguration;}
namespace mdaq{class __attribute__((annotate("$clingAutoload$interface/GlobalEvent.h")))  GlobalEvent;}
namespace mdaq{struct __attribute__((annotate("$clingAutoload$interface/AddTriggerNumber.h")))  eventTimes;}
typedef struct HVConfiguration HVConfiguration __attribute__((annotate("$clingAutoload$interface/DemonstratorConfiguration.h"))) ;
)DICTFWDDCLS";
    static const char* payloadCode = R"DICTPAYLOAD(
#line 1 "Dict dictionary payload"


#define _BACKWARD_BACKWARD_WARNING_H
// Inline headers
#include "interface/DemonstratorConfiguration.h"
#include "interface/DemonstratorConstants.h"
#include "interface/GlobalEvent.h"
#include "interface/V1743Event.h"
#include "interface/V1743Configuration.h"
#include "interface/AddTriggerNumber.h"
#include "interface/TriggerBoardReader.h"

#undef  _BACKWARD_BACKWARD_WARNING_H
)DICTPAYLOAD";
    static const char* classesHeaders[] = {
"HVConfiguration", payloadCode, "@",
"mdaq::ChannelConfiguration", payloadCode, "@",
"mdaq::DemonstratorConfiguration", payloadCode, "@",
"mdaq::GlobalEvent", payloadCode, "@",
"mdaq::GroupConfiguration", payloadCode, "@",
"mdaq::V1743Configuration", payloadCode, "@",
"mdaq::V1743Event", payloadCode, "@",
"mdaq::eventTimes", payloadCode, "@",
nullptr
};
    static bool isInitialized = false;
    if (!isInitialized) {
      TROOT::RegisterModule("Dict",
        headers, includePaths, payloadCode, fwdDeclCode,
        TriggerDictionaryInitialization_Dict_Impl, {}, classesHeaders, /*hasCxxModule*/false);
      isInitialized = true;
    }
  }
  static struct DictInit {
    DictInit() {
      TriggerDictionaryInitialization_Dict_Impl();
    }
  } __TheDictionaryInitializer;
}
void TriggerDictionaryInitialization_Dict() {
  TriggerDictionaryInitialization_Dict_Impl();
}
