#ifndef ADD_TRIGGERNUMBER_H
#define ADD_TRIGGERNUMBER_H

#include <iostream>
#include <vector>
#include <fstream>
#include "TFile.h"
#include "TString.h"
#include "TBranch.h"
#include "TH1.h"
#include "TCanvas.h"
#include "TTree.h"
#include "TChain.h"
#include "Logger.h"
#include "GlobalEvent.h"
#include "DemonstratorConstants.h"

namespace mdaq{

  struct eventTimes {
    float time, triggerNumber, timeDiff, matchingTimeCut, evtNum, runNum;
    unsigned long clockCycles, startTime;
 
    eventTimes() {}
    eventTimes(float Time, float trigger, unsigned long clock, unsigned long start) : time(Time), triggerNumber(trigger), clockCycles(clock), startTime(start) {}
  };


  class combineEvents {
  public:
    combineEvents() {
      f_out = new TFile("out.root", "RECREATE");
          
    }
    virtual ~combineEvents();

    std::string dataDir = "/home/milliqan/data/";
    std::string logDir = "/var/log/";

    void AddTriggerNumber(char* runList, char* run, float dClock, float configOffset);

    void startFile();
    void finishFile();
    void RegisterFile();
    void rotateFile();
    void printInfo();
 
   std::pair<std::vector<std::string>, std::vector<std::string> > getInputFiles(char* runList, char* run);

    std::string getPreviousFile(char* runList, char* run);
    bool previousFileMatch(char* runList, char* run, float daqTime);

    template<typename T> void printElement(T t, const int& width){
      const char separator = ' ';
      //std::cout << std::left << std::setw(width) << std::setfill(separator) << t;
    }

    //float deltaClock = 1e-4;
    int64_t deltaClock = 5e6;

    int runNumber = 0;
    int subRunNumber = 1;

    unsigned long clockCycles;
    float time;
    unsigned long startTime;
    unsigned long triggerNumber;

    unsigned long mClockCycles;
    float mTime;
    float mStartTime;
    float mTriggerNumber;
    float mTimeDiff;
    float mMatchingTimeCut;
    int mEvtNum;
    int mRunNum;
    int mTBEvent;

    unsigned long unClockCycles;
    float unTime;
    float unStartTime;
    float unTriggerNumber;
    float unTimeDiff;
    float unMatchingTimeCut;
    int unEvtNum;
    int unRunNum;
    int unTBEvent;

    int64_t daqTime;
    int64_t prevDAQTime = 0;
    int64_t triggerTime;
    int64_t closestTime;

    std::vector<int> matchedDigis;

    int tdcRollover = 0;

    TFile* firstFile;

    TTree * tree_out;
    TTree * unmatchedTriggerBoardEvents;
    TTree * DQM;
    TTree * t_previous;
    TTree * trigMetaData;
    TTree * trigMetaDataCopy;

    TChain * triggerChain;
    TChain * daqChain;

    TCanvas* c1;

    TH1F* h_multipleMatches;
    TH1I* h_numBoardsMatched;
    TH1I* h_unMatched;
 
    bool metaExists = false;

  private:

    TFile * f_out;
    TFile * f_previous;

    int unmatchedTriggers=0;
    int unmatchedDAQEvents=0;

  };

}

#endif
