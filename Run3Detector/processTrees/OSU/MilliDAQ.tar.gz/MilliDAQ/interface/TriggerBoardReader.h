#ifndef TRIGGERBOARD_READER_H
#define TRIGGERBOARD_READER_H

#ifndef NO_PYTHON_API_INSTALL
//#include <python3.6m/Python.h>
#include <python2.7/Python.h>
#endif

#include "Logger.h"
#include "AddTriggerNumber.h"

#ifndef NO_BOOST_INSTALL
#include <boost/property_tree/xml_parser.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/lexical_cast.hpp>
#endif

#include <iostream>
#include <bitset>
#include <thread>
#include <mutex>
#include <condition_variable>

#include "TFile.h"
#include "TTree.h"
#include "TH1.h"

namespace mdaq{

    struct histogramQueue {
      std::vector<unsigned long> triggerCount;
      std::vector<unsigned long> LVDSCount;

      histogramQueue() : triggerCount(16,0), LVDSCount(64,0) {}
    };

    class TriggerBoardReader {
    public:
      TriggerBoardReader();
      virtual ~TriggerBoardReader();

      int ResetClock();
      int getTriggerClock();
      PyObject* InitializeClock();
      void FinishFile();
      void writeTriggerFile();
      void StopRun();
      void StartFile();
      void maskTriggers(int enable);
      void getAllHistos();
      void getStartTime();
      std::pair<float, float> convertBitString(PyObject*);
      void GetPreviousRunNumber();
      void openTriggerBoard(std::string triggerConfig);
      bool SetTriggers(std::string triggerConfig);
      std::string GetPreviousConfigurationFile() const;
      void RegisterFile();
      void Rotate();
      void GetFWVersion();

      void IterateRunNumber()     { runNumber++; };
      void IterateSubRunNumber()  { subRunNumber++; };
      void ResetSubRunNumber()    { subRunNumber = 1; };

      unsigned int getRunNumber()    { return runNumber; };
      unsigned int getSubRunNumber() { return subRunNumber; };

      void DefineNewRun() {
        IterateRunNumber();
        ResetSubRunNumber();
        GetFWVersion();
        rolloversCounter = 0;
        prevClockCycles = 0;
      }

      std::string GetCurrentConfigFile() { return currentTriggerFile; };
      void SetCurrentConfigFile(std::string filename) { currentTriggerFile = filename; };


      TTree* t_TriggerBoard;
      TTree* t_Meta;
      TH1F* h_triggerCounts;
      TH1F* h_LVDSCounts;

    private:

      static PyObject *pName, *pNameClock; 
      static PyObject *pModule, *pModuleClock;
      static PyObject *pDict, *pDictClock;
      static PyObject *pFunc, *pFuncClock;
      static PyObject *pValue, *pValueClock;
      static PyObject *pResult, *pResultClock;

      TFile* f_TriggerBoard; 

      std::vector<eventTimes> eventQueue;
      std::vector<eventTimes> writeQueue;
      eventTimes tmpEvt;

      std::vector<int> triggerCountQueue = {0, 0, 0, 0, 0, 0, 0, 0};
      std::vector<int> triggerCountBuffer;

      histogramQueue histQueue;
      histogramQueue histBuffer;
 
      const Long64_t autoSaveEvery = 1000; // save every 1000 events
      const Long64_t maxNumberEventsPerFile = 1000; // start a new file every 1,000 events

      unsigned long clockCycles, clockCyclesFill, trigger, triggerFill;
      float time, timeFill;
      unsigned long startTime, startTimeFill;
      int rolloversFill;
      int rolloversCounter = 0;
      int prevClockCycles = 0;
      int fwVersion, setTrigger, coincidenceTime, deadTime, nLayerThreshold, nHitThreshold;
      float prescales[16];
      unsigned int digiMasks[8]; //hex numbers corresponding to digitizer channels

      unsigned int runNumber;
      unsigned int subRunNumber;

      std::string currentTriggerFile;

      std::thread triggerWrite;
      std::atomic<bool> isTriggerTreeFull;
      std::condition_variable triggerTreeFull;
      std::mutex triggerTreeMutex;

      std::mutex writeFileMutex;

    };

}


#endif
