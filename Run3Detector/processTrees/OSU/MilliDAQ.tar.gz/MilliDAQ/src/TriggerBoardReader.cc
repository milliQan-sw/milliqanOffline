#include "TriggerBoardReader.h"

using namespace std;


namespace mdaq{

  PyObject *TriggerBoardReader::pName, *TriggerBoardReader::pNameClock;
  PyObject *TriggerBoardReader::pModule, *TriggerBoardReader::pModuleClock;
  PyObject *TriggerBoardReader::pDict, *TriggerBoardReader::pDictClock;
  PyObject *TriggerBoardReader::pFunc, *TriggerBoardReader::pFuncClock;
  PyObject *TriggerBoardReader::pValue, *TriggerBoardReader::pValueClock;
  PyObject *TriggerBoardReader::pResult, *TriggerBoardReader::pResultClock;

  TriggerBoardReader::TriggerBoardReader(){

    f_TriggerBoard = new TFile("/home/milliqan/tmp/TriggerBoardOutput.root", "RECREATE");

    if(f_TriggerBoard->GetListOfKeys()->Contains("Events")){
      t_TriggerBoard = (TTree*)f_TriggerBoard->Get("Events");
      t_TriggerBoard->SetBranchAddress("clockCycles", &clockCyclesFill);
      t_TriggerBoard->SetBranchAddress("trigger", &triggerFill);
      t_TriggerBoard->SetBranchAddress("time", &timeFill);
      t_TriggerBoard->SetBranchAddress("startTime", &startTimeFill);
      t_TriggerBoard->SetBranchAddress("rollovers", &rolloversFill);
    }
    else {
      t_TriggerBoard = new TTree("Events", "Trigger Board Events");
      t_TriggerBoard->Branch("clockCycles", &clockCyclesFill);
      t_TriggerBoard->Branch("trigger", &triggerFill);
      t_TriggerBoard->Branch("time", &timeFill);
      t_TriggerBoard->Branch("startTime", &startTimeFill);
      t_TriggerBoard->Branch("rollovers", &rolloversFill);
    }
    
    if(f_TriggerBoard->GetListOfKeys()->Contains("MetaData")){
      t_Meta = (TTree*)f_TriggerBoard->Get("MetaData");
      t_Meta->SetBranchAddress("fwVersion", &fwVersion);
      t_Meta->SetBranchAddress("trigger", &setTrigger);
      t_Meta->SetBranchAddress("deadTime", &deadTime);
      t_Meta->SetBranchAddress("coincidenceTime", &coincidenceTime);
      t_Meta->SetBranchAddress("nLayerThreshold", &nLayerThreshold);
      t_Meta->SetBranchAddress("nHitThreshold", &nHitThreshold);
      t_Meta->SetBranchAddress("prescale0", &prescales[0]);
      t_Meta->SetBranchAddress("prescale1", &prescales[1]);
      t_Meta->SetBranchAddress("prescale2", &prescales[2]);
      t_Meta->SetBranchAddress("prescale3", &prescales[3]);
      t_Meta->SetBranchAddress("prescale4", &prescales[4]);
      t_Meta->SetBranchAddress("prescale5", &prescales[5]);
      t_Meta->SetBranchAddress("prescale6", &prescales[6]);
      t_Meta->SetBranchAddress("prescale7", &prescales[7]);
      t_Meta->SetBranchAddress("prescale8", &prescales[8]);
      t_Meta->SetBranchAddress("prescale9", &prescales[9]);
      t_Meta->SetBranchAddress("prescale10", &prescales[10]);
      t_Meta->SetBranchAddress("prescale11", &prescales[11]);
      t_Meta->SetBranchAddress("prescale12", &prescales[12]);
      t_Meta->SetBranchAddress("prescale13", &prescales[13]);
      t_Meta->SetBranchAddress("prescale14", &prescales[14]);
      t_Meta->SetBranchAddress("prescale15", &prescales[15]);
      t_Meta->SetBranchAddress("channelMask0", &digiMasks[0]);
      t_Meta->SetBranchAddress("channelMask1", &digiMasks[1]);
      t_Meta->SetBranchAddress("channelMask2", &digiMasks[2]);
      t_Meta->SetBranchAddress("channelMask3", &digiMasks[3]);
      t_Meta->SetBranchAddress("channelMask4", &digiMasks[4]);
      t_Meta->SetBranchAddress("channelMask5", &digiMasks[5]);
      t_Meta->SetBranchAddress("channelMask6", &digiMasks[6]);
      t_Meta->SetBranchAddress("channelMask7", &digiMasks[7]);

    }
    else {
      t_Meta = new TTree("MetaData", "Trigger Board Meta Data");
      t_Meta->Branch("fwVersion", &fwVersion);
      t_Meta->Branch("trigger", &setTrigger);
      t_Meta->Branch("deadTime", &deadTime);
      t_Meta->Branch("coincidenceTime", &coincidenceTime);
      t_Meta->Branch("nLayerThreshold", &nLayerThreshold);
      t_Meta->Branch("nHitThreshold", &nHitThreshold);
      t_Meta->Branch("prescale0", &prescales[0]);
      t_Meta->Branch("prescale1", &prescales[1]);
      t_Meta->Branch("prescale2", &prescales[2]);
      t_Meta->Branch("prescale3", &prescales[3]);
      t_Meta->Branch("prescale4", &prescales[4]);
      t_Meta->Branch("prescale5", &prescales[5]);
      t_Meta->Branch("prescale6", &prescales[6]);
      t_Meta->Branch("prescale7", &prescales[7]);
      t_Meta->Branch("prescale8", &prescales[8]);
      t_Meta->Branch("prescale9", &prescales[9]);
      t_Meta->Branch("prescale10", &prescales[10]);
      t_Meta->Branch("prescale11", &prescales[11]);
      t_Meta->Branch("prescale12", &prescales[12]);
      t_Meta->Branch("prescale13", &prescales[13]);
      t_Meta->Branch("prescale14", &prescales[14]);
      t_Meta->Branch("prescale15", &prescales[15]);
      t_Meta->Branch("channelMask0", &digiMasks[0]);
      t_Meta->Branch("channelMask1", &digiMasks[1]);
      t_Meta->Branch("channelMask2", &digiMasks[2]);
      t_Meta->Branch("channelMask3", &digiMasks[3]);
      t_Meta->Branch("channelMask4", &digiMasks[4]);
      t_Meta->Branch("channelMask5", &digiMasks[5]);
      t_Meta->Branch("channelMask6", &digiMasks[6]);
      t_Meta->Branch("channelMask7", &digiMasks[7]);
    }

    h_triggerCounts = new TH1F("h_triggerCounts", "Number of Triggers Fired", 16, 0, 16);
    h_LVDSCounts = new TH1F("h_LVDSCounts", "Clock Cycles LVDS Channels Were High", 64, 0, 64);

    triggerWrite = std::thread(&TriggerBoardReader::writeTriggerFile, this);
    { std::unique_lock<std::mutex> lk(triggerTreeMutex);
      isTriggerTreeFull.store(false);
    }

    SetCurrentConfigFile(GetPreviousConfigurationFile());
    GetPreviousRunNumber();
    IterateRunNumber();
    ResetSubRunNumber();
    GetFWVersion();
    mdaq::Logger::instance().info("TriggeBoardReader", TString(Form("Trigger board run number %i", getRunNumber())));

  }

  TriggerBoardReader::~TriggerBoardReader() {
    mdaq::Logger::instance().info("TriggerBoardReader", "Trigger Board Reader destructor called");
    if(f_TriggerBoard && f_TriggerBoard->IsOpen()) StopRun();
    triggerWrite.join();
    if(f_TriggerBoard) delete f_TriggerBoard;
  }

  std::pair<float, float> TriggerBoardReader::convertBitString(PyObject *output){
    unsigned long result = PyInt_AsLong(output);
    std::bitset<64> b_result = result;
    std::bitset<8> b_trigger;
    std::bitset<56> b_clock;
    for(int i=0; i < 64; i++){
      if(i < 56) b_clock[i] = b_result[i];
      else b_trigger[i-56] = b_result[i];
    }

    float clock = b_clock.to_ulong();
    float trigger = b_trigger.to_ulong();
    std::pair<float, float> p_out(clock, trigger);

    return p_out;

  }

  PyObject* TriggerBoardReader::InitializeClock(){

    mdaq::Logger::instance().info("TriggerBoardReader", "Initializing Clock");

    std::this_thread::sleep_for(chrono::seconds(5));

    // Initialize the Python Interpreter
    if(Py_IsInitialized() == false) Py_Initialize();

    //mdaq::Logger::instance().info("TriggerBoardReader", "python initialized");

    PyObject *result = NULL;
    PyObject *temp;


    // Build the name object
    pNameClock = PyString_FromString((char*)"triggerBoard");

    // Load the module object
    pModuleClock = PyImport_Import(pNameClock);

    // pDict is a borrowed reference 
    pDictClock = PyModule_GetDict(pModuleClock);

    // pFunc is also a borrowed reference 
    temp = PyDict_GetItemString(pDictClock, (char*)"runClass");

    Py_XINCREF(temp);
    Py_XDECREF(pFuncClock);
    pFuncClock = temp;
    Py_INCREF(Py_None);
    result = Py_None;

    return result;

  }

  void TriggerBoardReader::writeTriggerFile(){
 
   std::this_thread::sleep_for(chrono::seconds(1)); //try sleeping to avoid getting mutex at same time
 
    while (true){

      { std::unique_lock<std::mutex> lk2(triggerTreeMutex);
        
        triggerTreeFull.wait(lk2, [&]() {return isTriggerTreeFull.load();});

        mdaq::Logger::instance().info("TriggerBoardReader", TString(Form("WriteTriggerFile runNumber %i", runNumber)));

        FinishFile();

        mdaq::Logger::instance().info("TriggerBoardReader", "FinishedFile complete");

        isTriggerTreeFull.store(false);
      }

    }

    return;

  }

  void TriggerBoardReader::FinishFile(){

    if(!f_TriggerBoard->IsOpen()) StartFile();

    f_TriggerBoard->cd();

    for(auto& event : writeQueue){
      timeFill = event.time;
      clockCyclesFill = event.clockCycles;
      triggerFill = event.triggerNumber;
      startTimeFill = event.startTime;
      if(clockCyclesFill < (prevClockCycles - pow(2, 50))) rolloversCounter++;
      rolloversFill = rolloversCounter;
      prevClockCycles = clockCyclesFill;
      t_TriggerBoard->Fill();
    }

    for(int i=0; i < histBuffer.triggerCount.size(); i++){
        h_triggerCounts->Fill(i, (double)histBuffer.triggerCount[i]);
    }
    for(int i=0; i < histBuffer.LVDSCount.size(); i++){
        h_LVDSCounts->Fill(i, (double)histBuffer.LVDSCount[i]);
    }

    t_Meta->Fill();

    try{
      t_TriggerBoard->Write("", TObject::kOverwrite);
      t_Meta->Write("", TObject::kOverwrite);
      h_triggerCounts->Write();
      h_LVDSCounts->Write();
    }
    catch(...){
      mdaq::Logger::instance().info("TriggerBoardReader", "Exception");
    }

    f_TriggerBoard->Close(); //closing trigger board file causes crash when restart, error points to write action UpdateAll

    int test = rename("/home/milliqan/tmp/TriggerBoardOutput.root", TString(Form("/home/milliqan/data/TriggerBoard_Run%d.%d.root", runNumber, subRunNumber)));
    mdaq::Logger::instance().info("TriggerBoardReader", TString(Form("Saving Trigger Board File TriggerBoard_Run%d.%d.root", runNumber, subRunNumber)));

    RegisterFile();
    IterateSubRunNumber();
  }

  void TriggerBoardReader::StopRun(){

    if(eventQueue.size()>0) Rotate(); 
    if(f_TriggerBoard->IsOpen()) f_TriggerBoard;

    Py_DECREF(pValue);

    // Clean up
    Py_DECREF(pModule);
    Py_DECREF(pName);
    Py_DECREF(pFuncClock);

    // Finish the Python Interpreter
    Py_Finalize();

  }

  void TriggerBoardReader::Rotate() {

    mdaq::Logger::instance().info("TriggerBoardReader", TString(Form("Rotate runNumber %i", runNumber)));

    { std::unique_lock<std::mutex> lk(triggerTreeMutex);
      writeQueue = eventQueue;
      eventQueue.clear();
      histBuffer = histQueue;
      histQueue.triggerCount = std::vector<unsigned long>(16,0);
      histQueue.LVDSCount = std::vector<unsigned long>(64,0);
      isTriggerTreeFull.store(true);
    }
    triggerTreeFull.notify_all();

  }

  void TriggerBoardReader::StartFile(){

    f_TriggerBoard = new TFile("/home/milliqan/tmp/TriggerBoardOutput.root", "UPDATE");

    if(f_TriggerBoard->GetListOfKeys()->Contains("Events")){
      t_TriggerBoard = (TTree*)f_TriggerBoard->Get("Events");
      t_TriggerBoard->SetBranchAddress("clockCycles", &clockCyclesFill);
      t_TriggerBoard->SetBranchAddress("trigger", &triggerFill);
      t_TriggerBoard->SetBranchAddress("time", &timeFill);
      t_TriggerBoard->SetBranchAddress("startTime", &startTimeFill);
      t_TriggerBoard->SetBranchAddress("rollovers", &rolloversFill);

    }
    else {
      t_TriggerBoard = new TTree("Events", "Trigger Board Events");
      t_TriggerBoard->Branch("clockCycles", &clockCyclesFill);
      t_TriggerBoard->Branch("trigger", &triggerFill);
      t_TriggerBoard->Branch("time", &timeFill);
      t_TriggerBoard->Branch("startTime", &startTimeFill);
      t_TriggerBoard->Branch("rollovers", &rolloversFill);

    }

    if(f_TriggerBoard->GetListOfKeys()->Contains("MetaData")){
      t_Meta = (TTree*)f_TriggerBoard->Get("MetaData");
      t_Meta->SetBranchAddress("fwVersion", &fwVersion);
      t_Meta->SetBranchAddress("trigger", &setTrigger);
      t_Meta->SetBranchAddress("deadTime", &deadTime);
      t_Meta->SetBranchAddress("coincidenceTime", &coincidenceTime);
      t_Meta->SetBranchAddress("nLayerThreshold", &nLayerThreshold);
      t_Meta->SetBranchAddress("nHitThreshold", &nHitThreshold);
      t_Meta->SetBranchAddress("prescale0", &prescales[0]);
      t_Meta->SetBranchAddress("prescale1", &prescales[1]);
      t_Meta->SetBranchAddress("prescale2", &prescales[2]);
      t_Meta->SetBranchAddress("prescale3", &prescales[3]);
      t_Meta->SetBranchAddress("prescale4", &prescales[4]);
      t_Meta->SetBranchAddress("prescale5", &prescales[5]);
      t_Meta->SetBranchAddress("prescale6", &prescales[6]);
      t_Meta->SetBranchAddress("prescale7", &prescales[7]);
      t_Meta->SetBranchAddress("prescale8", &prescales[8]);
      t_Meta->SetBranchAddress("prescale9", &prescales[9]);
      t_Meta->SetBranchAddress("prescale10", &prescales[10]);
      t_Meta->SetBranchAddress("prescale11", &prescales[11]);
      t_Meta->SetBranchAddress("prescale12", &prescales[12]);
      t_Meta->SetBranchAddress("prescale13", &prescales[13]);
      t_Meta->SetBranchAddress("prescale14", &prescales[14]);
      t_Meta->SetBranchAddress("prescale15", &prescales[15]);
      t_Meta->SetBranchAddress("channelMask0", &digiMasks[0]);
      t_Meta->SetBranchAddress("channelMask1", &digiMasks[1]);
      t_Meta->SetBranchAddress("channelMask2", &digiMasks[2]);
      t_Meta->SetBranchAddress("channelMask3", &digiMasks[3]);
      t_Meta->SetBranchAddress("channelMask4", &digiMasks[4]);
      t_Meta->SetBranchAddress("channelMask5", &digiMasks[5]);
      t_Meta->SetBranchAddress("channelMask6", &digiMasks[6]);
      t_Meta->SetBranchAddress("channelMask7", &digiMasks[7]);
    }
    else {
      t_Meta = new TTree("MetaData", "Trigger Board Meta Data");
      t_Meta->Branch("fwVersion", &fwVersion);
      t_Meta->Branch("trigger", &setTrigger);
      t_Meta->Branch("deadTime", &deadTime);
      t_Meta->Branch("coincidenceTime", &coincidenceTime);
      t_Meta->Branch("nLayerThreshold", &nLayerThreshold);
      t_Meta->Branch("nHitThreshold", &nHitThreshold);
      t_Meta->Branch("prescale0", &prescales[0]);
      t_Meta->Branch("prescale1", &prescales[1]);
      t_Meta->Branch("prescale2", &prescales[2]);
      t_Meta->Branch("prescale3", &prescales[3]);
      t_Meta->Branch("prescale4", &prescales[4]);
      t_Meta->Branch("prescale5", &prescales[5]);
      t_Meta->Branch("prescale6", &prescales[6]);
      t_Meta->Branch("prescale7", &prescales[7]);
      t_Meta->Branch("prescale8", &prescales[8]);
      t_Meta->Branch("prescale9", &prescales[9]);
      t_Meta->Branch("prescale10", &prescales[10]);
      t_Meta->Branch("prescale11", &prescales[11]);
      t_Meta->Branch("prescale12", &prescales[12]);
      t_Meta->Branch("prescale13", &prescales[13]);
      t_Meta->Branch("prescale14", &prescales[14]);
      t_Meta->Branch("prescale15", &prescales[15]);
      t_Meta->Branch("channelMask0", &digiMasks[0]);
      t_Meta->Branch("channelMask1", &digiMasks[1]);
      t_Meta->Branch("channelMask2", &digiMasks[2]);
      t_Meta->Branch("channelMask3", &digiMasks[3]);
      t_Meta->Branch("channelMask4", &digiMasks[4]);
      t_Meta->Branch("channelMask5", &digiMasks[5]);
      t_Meta->Branch("channelMask6", &digiMasks[6]);
      t_Meta->Branch("channelMask7", &digiMasks[7]);
    }

    h_triggerCounts = new TH1F("h_triggerCounts", "Number of Triggers Fired", 16, 0, 16);
    h_LVDSCounts = new TH1F("h_LVDSCounts", "Clock Cycles LVDS Channels Were High", 64, 0, 64);

  }

  int TriggerBoardReader::ResetClock() {

    // Initialize the Python Interpreter
    if(Py_IsInitialized() == false) Py_Initialize();

    // Build the name object
    pName = PyString_FromString((char*)"triggerBoard");

    // Load the module object
    pModule = PyImport_Import(pName);

    // pDict is a borrowed reference 
    pDict = PyModule_GetDict(pModule);

    // pFunc is also a borrowed reference 
    pFunc = PyDict_GetItemString(pDict, (char*)"runClass");

    if (PyCallable_Check(pFunc))
    {
      pValue=Py_BuildValue("(i)",(int*)17);
      PyErr_Print();
      pResult=PyObject_CallObject(pFunc,pValue);
      PyErr_Print();
    }else
    {
      PyErr_Print();
    }
    //mdaq::Logger::instance().info("TriggerBoardReader", "Output: " + TString(Form("%d", PyInt_AsLong(pResult))));

    Py_DECREF(pValue);

    // Clean up
    Py_DECREF(pModule);
    Py_DECREF(pName);

    // Finish the Python Interpreter
    Py_Finalize();

    mdaq::Logger::instance().info("TriggerBoardReader", "Reset Trigger Board Clock");

    return 0;

  }

  void TriggerBoardReader::maskTriggers(int enable) {

    // Initialize the Python Interpreter
    if(Py_IsInitialized() == false) Py_Initialize();

    // Build the name object
    pName = PyString_FromString((char*)"triggerBoard");

    // Load the module object
    pModule = PyImport_Import(pName);

    // pDict is a borrowed reference 
    pDict = PyModule_GetDict(pModule);

    // pFunc is also a borrowed reference 
    pFunc = PyDict_GetItemString(pDict, (char*)"runClass");

    if (PyCallable_Check(pFunc))
    {
      pValue=Py_BuildValue("i,[i]",(int*)3, enable);
      PyErr_Print();
      pResult=PyObject_CallObject(pFunc,pValue);
      PyErr_Print();
    }else
    {
      PyErr_Print();
    }
    
    mdaq::Logger::instance().info("TriggerBoardReader", "maskTriggers");

  }

  void TriggerBoardReader::getAllHistos() {
  
    // Initialize the Python Interpreter
    if(Py_IsInitialized() == false) Py_Initialize();
    
    // Build the name object
    pName = PyString_FromString((char*)"triggerBoard");

    // Load the module object
    pModule = PyImport_Import(pName);

    // pDict is a borrowed reference 
    pDict = PyModule_GetDict(pModule);

    // pFunc is also a borrowed reference 
    pFunc = PyDict_GetItemString(pDict, (char*)"runClass");


    //Get the trigger histograms
    if (PyCallable_Check(pFunc))
    {
      pValue=Py_BuildValue("(i)",(int*)99);
      PyErr_Print();
      pResult=PyObject_CallObject(pFunc,pValue);
      PyErr_Print();
    }else
    {
      PyErr_Print();
    }

    if(!PyList_Check(pResult)) mdaq::Logger::instance().error("TriggerBoardReader", "Trigger board did not return a valid histogram");
 
    for(int trig=0; trig < PyList_Size(pResult); trig++){
        unsigned long result = PyInt_AsUnsignedLongLongMask(PyList_GetItem(pResult, trig));

        //mdaq::Logger::instance().info("TriggerBoardReader", TString(Form("Number of triggers for trigger %i: %i", trig, result)));
        histQueue.triggerCount[trig] = histQueue.triggerCount[trig] + result;
    }

    //Get the LVDS histograms
    if (PyCallable_Check(pFunc))
    {
      pValue=Py_BuildValue("(i)",(int*)98);
      PyErr_Print();
      pResult=PyObject_CallObject(pFunc,pValue);
      PyErr_Print();
    }else
    {
      PyErr_Print();
    }

    if(!PyList_Check(pResult)) mdaq::Logger::instance().error("TriggerBoardReader", "Trigger board did not return a valid histogram");

    for(int trig=0; trig < PyList_Size(pResult); trig++){
        unsigned long result = PyInt_AsUnsignedLongLongMask(PyList_GetItem(pResult, trig));

        //mdaq::Logger::instance().info("TriggerBoardReader", TString(Form("Number of triggers for LVDS %i: %i", trig, result)));
        histQueue.LVDSCount[trig] = histQueue.LVDSCount[trig] + result;
    }

  }

  int TriggerBoardReader::getTriggerClock() {

    bool printTriggers=false;

    if (PyCallable_Check(pFuncClock))
    {
      pValueClock=Py_BuildValue("(i)",(int*)16);
      PyErr_Print();
      pResultClock=PyObject_CallObject(pFuncClock,pValueClock);
      Py_DECREF(pValueClock);
      PyErr_Print();
    }else
    {
      PyErr_Print();
    }
    
    if(!PyList_Check(pResultClock)) mdaq::Logger::instance().error("TriggerBoardReader", "Trigger board did not return a valid list of triggers and clocks");
    //mdaq::Logger::instance().info("TriggerBoardReader", "Printing array of triggers and clocks --------------------------------------------------");

    for(int trig=0; trig < PyList_Size(pResultClock); trig++){
        unsigned long long thisClock = PyInt_AsUnsignedLongLongMask(PyList_GetItem(PyList_GetItem(pResultClock, trig), 0));
        unsigned long thisTrig = PyInt_AsUnsignedLongLongMask(PyList_GetItem(PyList_GetItem(pResultClock, trig), 1));
        
        if (thisClock == 0) continue;
        if(printTriggers && trig==0) mdaq::Logger::instance().info("TriggerBoardReader", "Printing array of triggers and clocks --------------------------------------------------");


        clockCycles = thisClock; // b_clock.to_ulong();
        trigger = thisTrig; // b_trigger.to_ulong();
        time = (double)thisClock / (50.0e6); //(b_clock.to_ulong()) / (50.0e6); //clock fires at 50MHz

        int entries = eventQueue.size();       

        if(printTriggers) mdaq::Logger::instance().info("TriggerBoardReader", TString(Form("Converted entries %d, clock %ul, trigger %ul , and time %.15f", entries, clockCycles, trigger, time)));
        if(trigger > 0){
            tmpEvt = eventTimes(time, trigger, clockCycles, startTime);
            eventQueue.push_back(tmpEvt);

        }

        if(eventQueue.size() >= maxNumberEventsPerFile) {
          Rotate();
        }

        //Temp to check output of getAllHistos
        if(eventQueue.size() % 100 == 0) {
          getAllHistos();
        }

    }

    Py_DECREF(pResultClock);

    return 0;

  }

  void TriggerBoardReader::getStartTime() {

    // Initialize the Python Interpreter
    if(Py_IsInitialized() == false) Py_Initialize();

    // Build the name object
    pName = PyString_FromString((char*)"triggerBoard");

    // Load the module object
    pModule = PyImport_Import(pName);

    // pDict is a borrowed reference 
    pDict = PyModule_GetDict(pModule);

    // pFunc is also a borrowed reference 
    pFunc = PyDict_GetItemString(pDict, (char*)"runClass");

    if (PyCallable_Check(pFunc))
    {
      pValue=Py_BuildValue("(i)",(int*)18);
      PyErr_Print();
      pResult=PyObject_CallObject(pFunc,pValue);
      PyErr_Print();
    }else
    {
      PyErr_Print();
    }

    if(!PyInt_Check(pResult)) mdaq::Logger::instance().error("TriggerBoardReader", "Trigger board did not return a valid start time");

    mdaq::Logger::instance().info("TriggerBoardReader", TString(Form("Start time for trigger board: %ul", PyInt_AsUnsignedLongMask(pResult))));

    startTime = PyInt_AsUnsignedLongMask(pResult);

  }

  void TriggerBoardReader::GetPreviousRunNumber() {

    // read the most recent run from /var/log/MilliDAQ_RunList.log
    std::fstream fin;
    fin.open("/var/log/MilliDAQ_RunList.log");

    std::string cfgPath;

    runNumber = 0;
    subRunNumber = 0;

    // find the most recent entry
    if(fin.is_open()) {
      while(true) {
        fin >> runNumber >> subRunNumber >> cfgPath;
        if(!fin.good()) break;
      }
    }
    
    return;
  }

  bool TriggerBoardReader::SetTriggers(std::string triggerConfig) {

    // Initialize the Python Interpreter
    if(Py_IsInitialized() == false) Py_Initialize();

    // Build the name object
    pName = PyString_FromString((char*)"triggerBoard");

    // Load the module object
    pModule = PyImport_Import(pName);

    // pDict is a borrowed reference 
    pDict = PyModule_GetDict(pModule);

    // pFunc is also a borrowed reference 
    pFunc = PyDict_GetItemString(pDict, (char*)"runClass");

    const char * config = triggerConfig.c_str();
    PyObject* pyConfig = PyString_FromString(config);

    if (PyCallable_Check(pFunc))
    {
      pValue=Py_BuildValue("i,[s]",(int*)15, config);

      PyErr_Print();
      pResult=PyObject_CallObject(pFunc,pValue);
      PyErr_Print();
    }else
    {
      PyErr_Print();
    }

    if(!PyList_Check(pResult)) mdaq::Logger::instance().error("TriggerBoardReader", "Trigger board did not set config file correctly!");

    long trigOut = PyInt_AsLong(PyList_GetItem(pResult, 0));
    long deadTimeOut = PyInt_AsLong(PyList_GetItem(pResult, 1));
    long coincidenceTimeOut = PyInt_AsLong(PyList_GetItem(pResult, 2));
    long layerThreshOut = PyInt_AsLong(PyList_GetItem(pResult, 3));
    long hitThreshOut = PyInt_AsLong(PyList_GetItem(pResult, 4));

    PyObject* prescaleArrayOut = PyList_GetItem(pResult, 5);
    PyObject* chanMaskArrayOut = PyList_GetItem(pResult, 6);

    if(PyList_Size(prescaleArrayOut) != 16){
      mdaq::Logger::instance().info("TriggerBoardReader", "Warning: Did not get 16 prescale values from config file");
    }
    else{
      for(int i=0; i < PyList_Size(prescaleArrayOut); i++){
        prescales[i] = (float)PyFloat_AsDouble(PyList_GetItem(prescaleArrayOut, i));
      }
    }

    if(PyList_Size(chanMaskArrayOut) != 8){
      mdaq::Logger::instance().info("TriggerBoardReader", TString(Form("Warning: Did not get 8 channel mask values from config file, got %i",PyList_Size(prescaleArrayOut))));
    }
    else{
      for(int i=0; i < PyList_Size(chanMaskArrayOut); i++){
        digiMasks[i] = (unsigned int)PyInt_AsLong(PyList_GetItem(chanMaskArrayOut, i));
        mdaq::Logger::instance().info("TriggerBoardReader", TString(Form("Channel Mask %i", (unsigned int)PyInt_AsLong(PyList_GetItem(chanMaskArrayOut, i)))));
      }
    }

    setTrigger = (int)trigOut;
    deadTime = (int)deadTimeOut;
    coincidenceTime = (int)coincidenceTimeOut;
    nLayerThreshold = (int)layerThreshOut;
    nHitThreshold = (int)hitThreshOut;

    mdaq::Logger::instance().info("TriggerBoardReader", TString(Form("Configured trigger board:\n Trigger Board Configuration:\n\tTrigger: %i \n\tDead Time: %i \n\tCoincidence Time: %i \n\tnLayerThreshold: %i \n\tnHitThreshold: %i", 
				trigOut, deadTimeOut, coincidenceTimeOut, layerThreshOut, hitThreshOut)));

    return PyList_Check(pResult);

  }

  void TriggerBoardReader::GetFWVersion(){

    // Initialize the Python Interpreter
    if(Py_IsInitialized() == false) Py_Initialize();

    // Build the name object
    pName = PyString_FromString((char*)"triggerBoard");

    // Load the module object
    pModule = PyImport_Import(pName);

    // pDict is a borrowed reference 
    pDict = PyModule_GetDict(pModule);

    // pFunc is also a borrowed reference 
    pFunc = PyDict_GetItemString(pDict, (char*)"runClass");
    
    if (PyCallable_Check(pFunc))
    {
      pValue=Py_BuildValue("(i)",(int*)0);
      PyErr_Print();
      pResult=PyObject_CallObject(pFunc,pValue);
      PyErr_Print();
    }else
    {
      PyErr_Print();
    }

    if(!PyInt_Check(pResult)) mdaq::Logger::instance().error("TriggerBoardReader", "Trigger board did not return a valid firmware version");

    mdaq::Logger::instance().info("TriggerBoardReader", TString(Form("Trigger Board Firmware Version: %ul", PyInt_AsUnsignedLongMask(pResult))));

    fwVersion = PyInt_AsUnsignedLongMask(pResult);

  }


  // This function is used when restarting a run to ensure a new connection to serial is opened
  // if this function is not called the multiple open serial connections will cause slowed down communication
  void TriggerBoardReader::openTriggerBoard(std::string triggerConfig) {

    if(Py_IsInitialized() == false) Py_Initialize();

    // Build the name object
    pName = PyString_FromString((char*)"triggerBoard");

    // Load the module object
    pModule = PyImport_Import(pName);

    // pDict is a borrowed reference 
    pDict = PyModule_GetDict(pModule);

    // pFunc is also a borrowed reference 
    pFunc = PyDict_GetItemString(pDict, (char*)"openTriggerBoard");

    const char * config = triggerConfig.c_str();

    if (PyCallable_Check(pFunc))
    {
      pValue=Py_BuildValue("(s)",config);

      PyErr_Print();
      pResult=PyObject_CallObject(pFunc,pValue);
      PyErr_Print();
    }else
    {
      PyErr_Print();
    }

    return;

  }

  void TriggerBoardReader::RegisterFile() {
    std::fstream fout;
    fout.open("/var/log/TriggerBoard_RunList.log", std::fstream::out | std::fstream::app);
    fout << runNumber << "\t" << subRunNumber << "\t" << currentTriggerFile << std::endl;
    fout.close();
  }

  std::string TriggerBoardReader::GetPreviousConfigurationFile() const {

    // read the most recent run from /var/log/TriggerBoard_RunList.log
    std::fstream fin;
    fin.open("/var/log/TriggerBoard_RunList.log");

    // define cfgPath as the default configuration in case RunList.log can't be open or is empty
    std::string cfgPath = "/home/milliqan/MilliDAQ/config/triggerConfig/triggerDefault.py";

    int runNumber = 0;
    int subRunNumber = 0;

    // find the most recent entry
    if(fin.is_open()) {
      while(true) {
        fin >> runNumber >> subRunNumber >> cfgPath;
        if(!fin.good()) break;
      }
    }

    return cfgPath;
  }


}


